Description
===========
An example Hello Worldproject.

#pip install twine
#python setup.py sdist - prepare package
#twine upload dist/*.tar.gz - upload